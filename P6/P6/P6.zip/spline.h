#ifndef SPLINE_H
#define SPLINE_H

#include "framework.h"
#include <vector>

class Spline
{
public:
	
	std::vector<Vector3> controlPoints;
	void addPoint( Vector3 point);
	Vector3 getInterpolatedPoint(float t);
	void draw(float increments);
};


#endif