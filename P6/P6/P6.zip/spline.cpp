#include "spline.h"
//Implementation ...
//TODO...

void Spline::addPoint(Vector3 point)
{
	this->controlPoints.push_back(point);
}

Vector3 Spline::getInterpolatedPoint(float t)
{
	Vector1x4 TM;
	TM.calculateBernstein(t);
	VectorPoints4x1 G(this->controlPoints[0],this->controlPoints[1], this->controlPoints[2], this->controlPoints[3]);

	return TM*G;
}

void Spline::draw(float increments)
{

	if (this->controlPoints.size() >= 4)
	{
		glColor3f(1,0,0);

		glBegin(GL_LINE_STRIP);

		Vector3 currentincrement;

		for(float t=0.0f; t <= 1.0f; t+=increments)
		{
			currentincrement = this->getInterpolatedPoint(t);

			glVertex3f(currentincrement.x, currentincrement.y, currentincrement.z);

		}

		glEnd();
	}
}
